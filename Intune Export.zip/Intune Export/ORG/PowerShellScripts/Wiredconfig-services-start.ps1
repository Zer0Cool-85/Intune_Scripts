﻿############# Start Wired config Services ##############
Start-Service -Name dot3svc
Set-Service -Name dot3svc -StartupType Automatic
