# SMBv2 exception script to re-enable SMBv2 for approved users
# Sets a key in the registry to act as a marker for users allowed to have SMBv2 enabled
# The detect and remediate script will check for the marker
try{
    $RegistryPath = 'HKLM:\Software\Bounteous'
    $Name         = 'SMBv2'
    $Value        = '1'
    if(-Not (Test-Path $RegistryPath)){
        New-Item -Path $RegistryPath
    } 
    $null = New-ItemProperty -Path $RegistryPath -Name $Name -Value $Value -PropertyType DWORD -Force
    Set-SmbServerConfiguration -EnableSMB2Protocol $true -Confirm:$false
    $smbV2 = (Get-SmbServerConfiguration).EnableSMB2Protocol
    if($smbV2){
        Write-Output "SMBv2 successfully re-enabled"
        Exit 0
    }else{
        Write-Output "Error re-enabling SMBv2"
        Exit 1
    }
    Exit 0
}catch{
    Exit 1
}
