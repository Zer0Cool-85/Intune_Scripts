# IPv6 exception script to re-enable IPv6
try{
    # Check registry to determine if IPv6 is disabled
    $RegistryPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters'
    $Name         = 'DisabledComponents'
    $Value        = '32'
    $IPv6 = (Get-ItemProperty -Path $RegistryPath).$Name

    if($IPv6 -ne 32){
        # If enabled, disable and re-check to ensure it was successfully set
        $null = Set-ItemProperty -Path $RegistryPath -Name $Name -Value $Value -Force
        $IPv6 = (Get-ItemProperty -Path $RegistryPath).$Name
        if($IPv6 -ne 32){
            Write-Output "Error re-enabling IPv6"
            Exit 1
        }else{
            Write-Output "IPv6 successfully re-enabled"
            Exit 0
        }
    }
}catch{
    Write-Output "Break -- Script error"
   Exit 1
}
